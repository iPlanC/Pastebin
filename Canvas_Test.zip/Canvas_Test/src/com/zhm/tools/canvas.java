package com.zhm.tools;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class canvas extends View{

	public canvas(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		// TODO Auto-generated constructor stub
	}
	
	public canvas(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
	}
	
	public canvas(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}
	
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		String str = "�¼κ�";
		Paint red = new Paint();
		Paint green = new Paint();
		Paint blue = new Paint();
		red.setColor(Color.RED);
		green.setColor(Color.GREEN);
		blue.setColor(Color.BLUE);
		
		red.setTextSize(5);
		green.setTextSize(10);
		blue.setTextSize(15);
		
		canvas.drawLine(10, 10, 250, 10, red);
		canvas.drawLine(10, 50, 250, 50, green);
		canvas.drawLine(10, 90, 250, 90, blue);
		
		red.setTextSize(50);
		red.setAlpha(50);
		canvas.drawText("���" + str, 20, 160, red);
		red.setAlpha(100);
		canvas.drawText("���" + str, 15, 155, red);
		red.setAlpha(255);
		canvas.drawText("���" + str, 10, 150, red);
	}
}
